package com.environmentsurvey.bean;

import java.util.Date;

public class SurveyStudentBean {
	private int id;
	private String name;
	private String description;
	private String volunteers;
	private String dateofsurvey;
	private String venue;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getVolunteers() {
		return volunteers;
	}
	public void setVolunteers(String volunteers) {
		this.volunteers = volunteers;
	}
	public String getDateofsurvey() {
		return dateofsurvey;
	}
	public void setDateofsurvey(String dateofsurvey) {
		this.dateofsurvey = dateofsurvey;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
	
	
	
}
