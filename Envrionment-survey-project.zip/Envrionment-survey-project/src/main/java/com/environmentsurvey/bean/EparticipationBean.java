package com.environmentsurvey.bean;

public class EparticipationBean {
private int id;
private  String name;
private String venue;
private String voulteers;
private String dofseminar;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getVenue() {
	return venue;
}
public void setVenue(String venue) {
	this.venue = venue;
}
public String getVoulteers() {
	return voulteers;
}
public void setVoulteers(String voulteers) {
	this.voulteers = voulteers;
}
public String getDofseminar() {
	return dofseminar;
}
public void setDofseminar(String dofseminar) {
	this.dofseminar = dofseminar;
}

}
